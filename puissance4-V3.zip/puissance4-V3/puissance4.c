/*********************************************************************************************/
/* Auteur : Louis Bruche                                                                     */
/* Date : 03/03/2020                                                                         */
/* Version : 1.1                                                                             */
/*                                                                                           */
/* Programme de jeu puissance 4 (2 joueurs)                                                  */
/*                                                                                           */
/*********************************************************************************************/

#include <stdio.h> // inclusion de la bibliotheque d'entrees/sorties
#include <stdlib.h> // inclusion de la bibliotheque standard

// Constantes fixant la taille du tableau de jeu.
#define WIDTH_TAB 7
#define HEIGHT_TAB 6

// Créer un type tableau pour pouvoir créer notre tableau de jeu.
typedef int Table[HEIGHT_TAB][WIDTH_TAB];



/*=======================================================================================================
Function <initGrille>
Cette procédure permet d'initialiser le tableau et de le remplir de cases vides ' '.

    Arguments :
    - Table grid <- Table tableau = corresponds to the game grid,

    Returns :
    - void = cette fonction ne renvoie rien
    */
void initGrille(Table grille) {

    int i, j;
    // Déclaration des variables pour pouvoir faire une double boucle.

    for (i=0; i < HEIGHT_TAB; i=i+1) {
        for (j=0; j < WIDTH_TAB; j=j+1) {
            grille[i][j] = ' ';
        }
    }
}


/*=======================================================================================================
Function <affichageGrille>
Cette fonction permet d'afficher le tableau sous la forme basique (prompt).
    Arguments :
    - Table grid <- Table tableau = corresponds to the game grid,

    Returns :
    - void = cette fonction ne renvoie rien
    */
void affichageGrille(Table grille) {
    
    int i, j;
    // Déclaration des variables pour pouvoir faire une double boucle.

    printf("\n  1   2   3   4   5   6   7");
    for (i=0; i < HEIGHT_TAB; i=i+1) {
        printf("\n");
        for (j=0; j < WIDTH_TAB; j=j+1) {
            printf("| %c ",grille[i][j]);
        }
        printf("|");
    }
}



/*=======================================================================================================
Function <grillePleine>
Cette fonction vérifie si la grille est pleine.

    Arguments :
    - Table grid <- Table tableau = corresponds to the game grid,

    Returns :
    - int = cette fonction renvoie un entier :
            - 1 = si le tableau est plein,
            - 0 = s'il ne l'est pas.
    */
int grillePleine(Table grille) {
    
    int i, j;
    // Déclaration des variables pour pouvoir faire une double boucle.
    int count = 0;

    for (i=0; i < HEIGHT_TAB; i=i+1) {
        for (j=0; j < WIDTH_TAB; j=j+1) {
            if (grille[i][j] != ' ') {
                count = count + 1;
            }
        }
    }
    if (count >= (HEIGHT_TAB*WIDTH_TAB)) {
        return 1;
    } else {
        return 0;
    }
}
// ======================================================================================================

/*=======================================================================================================
Function <remplirGrille>
Cette procédure permet de remplir la grille avec le jeton 'X'.

    Arguments :
    - Table grid <- Table tableau = corresponds to the game grid,

    Returns :
    - void = cette fonction ne renvoie rien
    */
void remplirGrille(Table grille) {
    
    int i, j;
    // Déclaration des variables pour pouvoir faire une double boucle.

    for (i=0; i < HEIGHT_TAB; i=i+1) {
        for (j=0; j < WIDTH_TAB; j=j+1) {
            grille[i][j] = 'X';
        }
    }
}
// ======================================================================================================

/*=======================================================================================================
Function <verifNumCase>
Cette fonction permet de vérifier si le numéro entré par l'utilisateur est valide,
ou non (s'il est compris entre 1 et 7).

    Arguments :
    - int caseNumber <- caseNumber = corresponds to the culumn number choosen by the player,

    Returns :
    - int = cette fonction renvoie un entier :
            - 0 = si la séléction est invalide,
            - 1 = si la séléction est correcte.

    */
int verifNumCase(int caseNumber) {

    if ((caseNumber >= 1) && (caseNumber <= 7)) {
        // printf("\nverifNumcase -> return 1");
        return 1;
    } else {
        // printf("\nverifNumcase -> return 0");
        return 0;
    }
}
// ======================================================================================================

/*=======================================================================================================
Function <verifGrilleEmplacementVide>
Cette fonction permet de vérifier via une boucle, si l'emplacement choisi par l'utilisateur est libre 
ou non.

    Arguments :
    - int colNumber <- caseNumber = corresponds to the culumn number choosen by the player,
    - Table grid <- Table tableau = corresponds to the game grid,

    Returns :
    - int = cette fonction renvoie un entier :
            - 404 = si la colonne est pleine,
            - count = renvoie la taille prise dans la colonne.

    */
int  verifGrilleEmplacementVide(int colNumber, Table grille) {
    // printf("\nverifGrilleEmplacementVide Debug : verifEmplacementGrille -> entree dans la fonction");

    // Browse the 'x' rows of the table to count the number of empty cells on the chosen 'y' column.
    int count = 0;
    int i;

    for (i = HEIGHT_TAB; i>=0; i--) {
        if (grille[i][colNumber] == ' ') {
            break;
        }
        count = i;

    }
    printf("\nverifGrilleEmplacementVide Debug : count apres la boucle -> %d",count);

    // Checks if the counter is greater than or equal to the height of the array.
    if (count == 0) {
        printf("\nverifEmplacementVide -> Return 100 (impossible ligne pleine)");
        return (100);
    } else {
        printf("\nverifEmplacementVide -> Return count %d",count);
        return count;
    }
}
// ======================================================================================================

/*=======================================================================================================
Function <addToken>
This procedure allows thanks to several conditions of verification if the placement of a token is possible.
If it is, a token is placed according to the player.

    Arguments :
    - Table grid <- Table tableau = corresponds to the game grid,
    - int playerID <- int = corresponds to the player who is currently playing.

    Returns :
    - void = this function does not return anything but modifies the game grid.

    */
void addToken(Table grid, int playerID) {

    int caseNumber, compteur;

    do {
        printf("\n>>> Choose a column : ");   
        scanf("%d", &caseNumber);
        
        compteur = verifGrilleEmplacementVide(caseNumber, grid);
    } while ((verifNumCase(caseNumber) == 0) );



    if (playerID == 0) {
        grid[compteur-1] [ caseNumber - 1 ] = 'X';
        printf("Debug -> Placement X");
    } else if (playerID == 1) {
        grid[compteur-1] [ caseNumber - 1 ] = 'O';
        printf("Debug -> Placement O");
    } else {
        printf("\nError : playerID unknow");
    }
}
// ======================================================================================================


int main() {

    int game =1;
    printf("Start program\n");
    // Créer une grille et l'initialise grace à la fonction 'initGrille'.
    Table tableau;
    int caseNumber;
    initGrille(tableau);
    do {
        addToken(tableau, 0);
        affichageGrille(tableau);
    } while (game == 1);

    printf("End program\n");
}